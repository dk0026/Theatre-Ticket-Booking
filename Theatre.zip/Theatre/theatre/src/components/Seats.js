import React, { useEffect, useState } from 'react';
import axios from 'axios';
const Seats = (props) => {
    const [tickets, setTickets] = useState([]);
    const [booked, setBooked] = useState(false)

    const bookSeat = (seatData) => {

        axios.put(`/tickets/${seatData.id}`, { booked: true }).then(data => {
            setBooked(!booked);

        }).catch(err => {
            console.log(err);
        })
        if (props.ticketNos.indexOf(seatData.ticketNo) === -1) {

            props.setTicketNos(ticketsNos => [...ticketsNos, seatData.ticketNo])
            props.setAmount(amount => amount + seatData.price)
        }

    }

    useEffect(() => {
        fetch("/api/tickets")
            .then((response) => response.json())
            .then((json) => setTickets(json.tickets))
    }, [booked])


    return (
        <div>
            <div className="row">
                {
                    tickets.map((ele) =>
                        <div id="maindiv" key={ele.id} onClick={() => bookSeat(ele)}>

                            {ele.ticketNo} <br />Rs.{ele.price}<br />{ele.booked ? <h6>Booked</h6> : <h6>Not Booked</h6>}

                        </div>
                    )}
            </div>

        </div>
    )
}

export default Seats
