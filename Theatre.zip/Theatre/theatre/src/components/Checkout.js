import * as React from 'react';

import Card from '@mui/material/Card';

import CardContent from '@mui/material/CardContent';

import Typography from '@mui/material/Typography';

export default function Checkout(props) {
    return (
        <Card sx={{ minWidth: 275 }}>
            <CardContent>
                <Typography sx={{ fontSize: 18 }} color="text.secondary">Ticket Booked Successfully!!!!
                </Typography>
                <Typography sx={{ fontSize: 16 }} color="text.secondary" gutterBottom>
                    Booking Details:
                </Typography>

                <Typography sx={{ fontSize: 14 }} color="text.secondary">Ticket Nos:
                    {
                        props.ticketNos.map((item) => <span>{item} {','}</span>)
                    }
                </Typography>
                <Typography sx={{ fontSize: 14 }} color="text.secondary">Total Amount:
                    {props.amount}
                </Typography>

            </CardContent>

        </Card>
    );
}
