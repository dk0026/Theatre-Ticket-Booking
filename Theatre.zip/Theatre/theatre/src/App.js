
import './App.css';
import { BrowserRouter, Switch, Route, Link, useHistory } from "react-router-dom";
import server from './server';
import Seats from './components/Seats';
import React, { useState } from 'react';
import Checkout from './components/Checkout';
function App() {
  const history = useHistory();
  const [ticketNos, setTicketNos] = useState([]);
  const [amount, setAmount] = useState(0);
  return (
    <div className="App">
      <div className="container">
        <h3 className="theatre">Screen</h3>
        <Seats ticketNos={ticketNos} setTicketNos={setTicketNos} amount={amount} setAmount={setAmount} />
        <h4>Ticket No:
          {
            ticketNos.map((item) => <span>{item} {','}</span>)
          }
        </h4>
        <h4>Ticket Amount: {amount}</h4>
        <BrowserRouter>
          <div id="container">
            <div>

              <Link to="/checkout"><button class="button" onClick={() => history.push("/checkout")} >Book Now</button></Link><br /><br />
            </div>
            <Switch>
              <Route exact path="/" element={<Seats />} />
              <Route exact path="/checkout" render={(props) => <Checkout ticketNos={ticketNos} amount={amount} {...props} />} />
            </Switch>
          </div>
        </BrowserRouter>
      </div>
    </div>
  );
}

export default App;
