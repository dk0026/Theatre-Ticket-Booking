import { createServer, Model } from "miragejs"
const tickets = [
    {
        "id": "t1",
        "ticketNo": "1A",
        "price": 100,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t2",
        "ticketNo": "1B",
        "price": 100,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t3",
        "ticketNo": "1C",
        "price": 100,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t4",
        "ticketNo": "1D",
        "price": 100,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t5",
        "ticketNo": "1E",
        "price": 100,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t6",
        "ticketNo": "1F",
        "price": 100,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t7",
        "ticketNo": "1G",
        "price": 100,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t8",
        "ticketNo": "1H",
        "price": 100,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t9",
        "ticketNo": "1I",
        "price": 100,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t10",
        "ticketNo": "1J",
        "price": 100,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t11",
        "ticketNo": "1K",
        "price": 100,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t12",
        "ticketNo": "1L",
        "price": 100,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t13",
        "ticketNo": "2A",
        "price": 200,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t14",
        "ticketNo": "2B",
        "price": 200,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t15",
        "ticketNo": "2C",
        "price": 200,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t16",
        "ticketNo": "2D",
        "price": 200,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t17",
        "ticketNo": "2E",
        "price": 200,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t18",
        "ticketNo": "2F",
        "price": 200,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t19",
        "ticketNo": "2G",
        "price": 200,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t20",
        "ticketNo": "2H",
        "price": 200,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t21",
        "ticketNo": "2I",
        "price": 200,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t22",
        "ticketNo": "2J",
        "price": 200,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t23",
        "ticketNo": "2K",
        "price": 200,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t24",
        "ticketNo": "2L",
        "price": 200,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t25",
        "ticketNo": "3A",
        "price": 300,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t26",
        "ticketNo": "3B",
        "price": 300,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t27",
        "ticketNo": "3C",
        "price": 300,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t28",
        "ticketNo": "3D",
        "price": 300,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t29",
        "ticketNo": "3E",
        "price": 300,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t30",
        "ticketNo": "3F",
        "price": 300,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t31",
        "ticketNo": "3G",
        "price": 300,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t32",
        "ticketNo": "3H",
        "price": 300,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t33",
        "ticketNo": "3I",
        "price": 300,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t34",
        "ticketNo": "3J",
        "price": 300,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t35",
        "ticketNo": "3K",
        "price": 300,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t36",
        "ticketNo": "3L",
        "price": 300,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t37",
        "ticketNo": "4A",
        "price": 400,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t38",
        "ticketNo": "4B",
        "price": 400,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t39",
        "ticketNo": "4C",
        "price": 400,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t40",
        "ticketNo": "4D",
        "price": 400,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t41",
        "ticketNo": "4E",
        "price": 400,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t42",
        "ticketNo": "4F",
        "price": 400,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t43",
        "ticketNo": "4G",
        "price": 400,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t44",
        "ticketNo": "4H",
        "price": 400,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t45",
        "ticketNo": "4I",
        "price": 400,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t46",
        "ticketNo": "4J",
        "price": 400,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t47",
        "ticketNo": "4K",
        "price": 400,
        "booked": false,
        "disabled": false
    },
    {
        "id": "t48",
        "ticketNo": "4L",
        "price": 400,
        "booked": false,
        "disabled": false
    },

];

const server = createServer({
    models: {
        tickets: Model,
    },
    seeds(server) {
        for (let i = 0; i < tickets.length; i++) {
            server.create("ticket", tickets[i])


        }

    },
    routes() {
        this.get("/api/tickets", (schema) => {
            return schema.tickets.all()
        })

        this.put("/tickets/:id", function (schema, request) {
            const parsedData = JSON.parse(request.requestBody)
            console.log(parsedData);
            let id = request.params.id
            return schema.tickets.find(id).update(parsedData)

        })
    },

})

export default server